
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://bcaodndndtkauazaxnyab.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJjYW9kZG5kdGthdWF6YXhueWFiIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3MDcyMTE5MCwiZXhwIjoyMDg2Mjk3MTkwfQ.R6o3R4V9hPXDWLmIgmVKNJbPb-BTyN4Rr5qUBXkNox0';

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
  realtime: {
    params: {
      eventsPerSecond: 10,
    },
  },
});
