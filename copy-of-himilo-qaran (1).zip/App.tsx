
import React, { useState, useEffect } from 'react';
import { 
  Role, Idea, User, AuditEntry, AppView, MembershipStatus, 
  ElectionEvent, CandidateRecord, VoteRecord
} from './types';
import { supabase } from './lib/supabase';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import AuthPage from './components/AuthPage';
import AdminUserManagement from './components/AdminUserManagement';
import GovernanceRegistry from './components/GovernanceRegistry';
import AdminCommittees from './components/AdminCommittees';
import AdminElections from './components/AdminElections';
import AdminCandidates from './components/AdminCandidates';
import AdminJobs from './components/AdminJobs';
import AuditLog from './components/AuditLog';
import InstitutionalMemory from './components/InstitutionalMemory';
import VotingTerminal from './components/VotingTerminal';
import ElectionResults from './components/ElectionResults';
import MemberIdeaSubmission from './components/MemberIdeaSubmission';
import GovernanceAssistant from './components/GovernanceAssistant';

const App: React.FC = () => {
  const [view, setView] = useState<AppView>('dashboard');
  const [activeIdeaId, setActiveIdeaId] = useState<string | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  
  const [users, setUsers] = useState<User[]>([]);
  const [ideas, setIdeas] = useState<Idea[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditEntry[]>([]);
  const [elections, setElections] = useState<ElectionEvent[]>([]);
  const [candidates, setCandidates] = useState<CandidateRecord[]>([]);
  const [votes, setVotes] = useState<VoteRecord[]>([]);
  
  const [status, setStatus] = useState<'connecting' | 'connected' | 'error'>('connecting');

  useEffect(() => {
    const initApp = async () => {
      try {
        const [
          { data: u }, { data: i }, { data: l }, { data: e }, { data: c }, { data: v }
        ] = await Promise.all([
          supabase.from('users').select('*'),
          supabase.from('ideas').select('*').order('created_at', { ascending: false }),
          supabase.from('audit_logs').select('*').order('timestamp', { ascending: false }).limit(50),
          supabase.from('elections').select('*'),
          supabase.from('candidates').select('*'),
          supabase.from('votes').select('*')
        ]);

        if (u) setUsers(u);
        if (i) setIdeas(i);
        if (l) setAuditLogs(l);
        if (e) setElections(e);
        if (c) setCandidates(c);
        if (v) setVotes(v);

        setStatus('connected');
        
        // Remove the HTML loader when React is ready
        const loader = document.getElementById('app-loader');
        if (loader) {
          loader.style.opacity = '0';
          setTimeout(() => loader.remove(), 500);
        }

      } catch (err) {
        console.error("Critical connection failure:", err);
        setStatus('error');
      }
    };

    initApp();

    const channel = supabase.channel('realtime-all')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'users' }, (p) => {
        if (p.eventType === 'INSERT') setUsers(prev => [...prev, p.new as User]);
        if (p.eventType === 'UPDATE') setUsers(prev => prev.map(x => x.id === p.new.id ? p.new as User : x));
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'ideas' }, (p) => {
        if (p.eventType === 'INSERT') setIdeas(prev => [p.new as Idea, ...prev]);
        if (p.eventType === 'UPDATE') setIdeas(prev => prev.map(x => x.id === p.new.id ? p.new as Idea : x));
      })
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, []);

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setIsAuthenticated(false);
  };

  if (status === 'error') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-hq-black p-8 text-center">
        <div className="space-y-6">
          <div className="text-6xl">📡</div>
          <h1 className="text-2xl font-black text-white uppercase">Xiriirka Database-ka waa fashilmay</h1>
          <p className="text-slate-400 max-w-sm">Nidaamku ma haleeli karo server-ka rasmiga ah. Fadlan hubi internet-kaaga.</p>
          <button onClick={() => window.location.reload()} className="px-10 py-4 bg-hq-green text-white font-black rounded-2xl shadow-xl">ISKU DAY MAR KALE</button>
        </div>
      </div>
    );
  }

  if (status === 'connecting') return null;

  if (!isAuthenticated) {
    return <AuthPage onLogin={handleLogin} onSignup={() => {}} availableUsers={users} />;
  }

  return (
    <div className="flex min-h-screen bg-hq-white font-sans text-hq-black overflow-hidden">
      <Sidebar 
        currentView={view} 
        setView={setView} 
        userRole={currentUser!.role} 
        elections={elections} 
        currentUser={currentUser!} 
      />
      
      <main className="flex-1 flex flex-col min-w-0 h-screen relative">
        <Header 
          user={currentUser!} 
          health={{participationRate: 88, captureRisk: 'Low', regionalBalance: 92, unresolvedGrievances: 0}} 
          onRoleSwitch={() => {}}
          onLogout={handleLogout}
        />
        
        <div className="flex-1 overflow-y-auto p-4 md:p-10 custom-scrollbar">
          {view === 'dashboard' && <Dashboard health={{participationRate: 88, captureRisk: 'Low', regionalBalance: 92, unresolvedGrievances: 0}} ideas={ideas} usersCount={users.length} onNavigate={setView} currentUser={currentUser!} auditLogs={auditLogs} />}
          {view === 'admin-membership' && <AdminUserManagement users={users} currentUser={currentUser!} onAddUser={() => {}} onUpdateUser={() => {}} onDeleteUser={() => {}} onUpdateStatus={() => {}} onUpdateRole={() => {}} />}
          {view === 'admin-policy' && <GovernanceRegistry ideas={ideas} userRole={currentUser!.role} onEnterStage={(id, stage) => { setActiveIdeaId(id); setView(stage); }} />}
          {view === 'voting-terminal' && <VotingTerminal elections={elections} candidates={candidates} votes={votes} currentUserId={currentUser!.id} onVote={() => {}} />}
          {view === 'admin-memory' && <InstitutionalMemory />}
          {view === 'admin-oversight' && <AuditLog auditLogs={auditLogs} />}
          {view === 'member-submission' && <MemberIdeaSubmission currentUser={currentUser!} onAddIdea={async (d) => { await supabase.from('ideas').insert([d]); setView('dashboard'); }} onNavigateToDashboard={() => setView('dashboard')} />}
        </div>
      </main>
      
      <GovernanceAssistant userRole={currentUser!.role} />
    </div>
  );
};

export default App;
